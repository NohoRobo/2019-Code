package org.usfirst.frc.team3328.robot.subsystems;

public interface Sheeder {
	
	void shoot();
	
	void feed();
	
	void stop();

	void setTo(double d);

	void hold();

	void rotateBox();

	

}
