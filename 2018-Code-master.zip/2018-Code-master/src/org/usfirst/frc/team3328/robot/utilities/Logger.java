package org.usfirst.frc.team3328.robot.utilities;

public class Logger {

	public Logger() {
	}

	public static void log(String string, double number, int logLevel) {
		System.out.println(string + number);
	}
	
}
