package org.usfirst.frc.team3328.robot.subsystems;

public interface Climb {
	
	void winch(double power);

}
