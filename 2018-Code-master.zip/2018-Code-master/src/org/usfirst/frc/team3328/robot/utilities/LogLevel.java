package org.usfirst.frc.team3328.robot.utilities;

public class LogLevel {
	
	public static int debug = 0;
	public static int info = 1;
	public static int error = 2;
	
}
